ANALYZE VERBOSE catalog;
SELECT count(*) AS cat_cnt FROM catalog;

ANALYZE VERBOSE enrollment;
SELECT count(*) AS enroll_cnt FROM enrollment;
