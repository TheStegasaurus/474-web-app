/* global $ */

var URL = 'https://seeds-jad006.c9users.io:8081/';

function start() {
alert("WHJAT");
  $.ajax({
    url: URL,
    method: 'GET'
  })
  .done(setClasses)
  .fail(displayError);
}


$(document).ready(function() {

google.charts.load('current', {'packages':['corechart']});
//google.charts.setOnLoadCallback(drawChart);



//The search function
  $("#submit_btn").click(function(e) {

    var search_term = $("#txtSearch").val();

  document.getElementById("major-id").innerHTML= "MAJOR: " + search_term.toUpperCase();


    removeList();

    if (search_term != "") {
      $.ajax({
        url: URL + "classes/" + search_term,
        method: 'GET'
      })
      .done(setClasses)
      .fail(displayError);
    }
  });
  

//The on-click function for the class list
$("#major_text").on('click','li',function (){
  var id = $(this).attr('name').split(" ");
  document.getElementById("class-id").innerHTML= "CLASS: " + id[0] + " " + id[1];


    $.ajax({
      url: URL + "class/" + id[0] + "/" + id[1],
      method: 'GET'
    })
    .done(updateClassInfo)
    .fail(displayError);




    $.ajax({
      url: URL + "instructor/" + id[0] + "/" + id[1],
      method: 'GET'
    })
    .done(drawChart)
    .fail(displayError);


});
  
  
});

//Updates the right side with info
function updateClassInfo (info) {
  if (info[0].Description == "")
    info[0].Description = "No description found";
  
  document.getElementById("class_description").innerHTML= info[0].Description;
  document.getElementById("class_title").innerHTML= "<b>" + info[0].Name + "</b>";
  document.getElementById("class_program").innerHTML= info[0].Program;
}

//Removes the list of items on the left
function removeList() {
  $('#class_list li').each(function () { // loops through all li
      $(this).remove(); // Remove li one by one
  });
}

//Sets the bullets to contain the info from the search
function setClasses (classes) {
    $.each(classes, function(index, item) {
      //Don't show courses with letters
      if (item.Code.length > 3)
        return;
      
      var code = '<li name="' + item.Prefix + ' ' + item.Code + '">';
      
      if (item.Not_offered != null) {
        code = code + '<font title="This class has not been offered in a while" color="#808080">';
      }
      
      //The extra font tag doesnt get cleaned up cause im lazy
      code = code + '<u>' + item.Prefix + ' ' + item.Code + '</u>: ' + item.Name + '. ' + item.Credits + "</font>";
      
      if (item.Fills != null) {
        code = code + ' <img src="exclamation-mark.png" alt="Mountain View" title="This class tends to fill up!">';
      }
      
      code = code + '</li>';
      $("#class_list").append(code);
    });
    
    //This sets the height of the right column to the height of its container so that it scrolls with the user
   $("#right-side").css('height',$("#row").innerHeight());
}

function displayError (err) {
  alert(JSON.stringify(err));
}

//$(start);

/*var el=$('#follow-scroll');
var elpos=el.offset().top;
$(window).scroll(function () {
    var y=$(this).scrollTop();
    if(y<elpos){el.stop().animate({'top':0},500);}
    else{el.stop().animate({'top':y-elpos},500);}
});
*/



  /*  $(window).on('scroll', function(event) {
          var element = $('#follow-scroll');
        var originalY = element.offsetTop;

    // Space between element and top of screen (when scrolling)
    var topMargin = 20;

    // Should probably be set in CSS; but here just for emphasis
    element.css('position', 'relative');
        var scrollTop = $(window).scrollTop();

        element.stop(false, false).animate({
            top: scrollTop < originalY
                    ? 0
                    : scrollTop - originalY + topMargin
        }, 300);
    });
*/


//===================================== Google api chart stuff ================================================


function drawChart(results) {
  

if (results.length === 0) {
    var chart = new google.visualization.PieChart(document.getElementById('chart'));
    chart.clearChart();
    document.querySelector('#chart').style.visibility = 'hidden';

    return;
}

var array = [["Instructor", "Number"]];
document.querySelector('#chart').style.visibility = 'visible';

$.each(results, function(index, item) {
  var i = [];
  i.push(item.Instructor, item.Count);
  array.push(i);
  //array = array + '[\'' + item.Instructor + '\', ' + item.Count + '],\n';
});

  
  var data = google.visualization.arrayToDataTable(array);

  var options = {
    title: 'Professor Distribution',
    'chartArea': {'width': '100%', 'height': '80%'},
    //pieSliceText: 'label',
    //legend: 'none'
  };

  var chart = new google.visualization.PieChart(document.getElementById('chart'));

  chart.draw(data, options);
}